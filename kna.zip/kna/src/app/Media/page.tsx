'use client';

import CarouselSection from "@/components/Media/CarouselSection";
import Header from "@/components/Media/Header";

const Services = () => {

    return (
            <div>
                <Header/>
                <CarouselSection/>
                
                
                
            </div>
    );
};

export default Services;