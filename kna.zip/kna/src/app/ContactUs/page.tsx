'use client';

import LetsTalk from "@/components/ContactUs/LetsTalk";
import "leaflet/dist/leaflet.css";


const ContactUs = () => {

    return (
            <div>
                <LetsTalk/>
            </div>
    );
};

export default ContactUs;