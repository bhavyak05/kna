// AUTO-GENERATED FILE — DO NOT EDIT MANUALLY

import img_0 from "@/marquee/AdaniWilmar.png";
import img_1 from "@/marquee/Affle.png";
import img_2 from "@/marquee/airtel.png";
import img_3 from "@/marquee/Akzonobel.png";
import img_4 from "@/marquee/amara-raja-horigontal-logos.png";
import img_5 from "@/marquee/AMI.png";
import img_6 from "@/marquee/Andhra.png";
import img_7 from "@/marquee/Antony.png";
import img_8 from "@/marquee/Apollo Tyres.png";
import img_9 from "@/marquee/Ashiana.png";
import img_10 from "@/marquee/Aster DM.png";
import img_11 from "@/marquee/AU bank.png";
import img_12 from "@/marquee/Awfis.png";
import img_13 from "@/marquee/Bajaj Consumer.png";
import img_14 from "@/marquee/Bajel.png";
import img_15 from "@/marquee/Balco.png";
import img_16 from "@/marquee/bharatelectro.png";
import img_17 from "@/marquee/Bharti Hexa.png";
import img_18 from "@/marquee/Bikaji.png";
import img_19 from "@/marquee/Black Box.png";
import img_20 from "@/marquee/Bliss.png";
import img_21 from "@/marquee/BMWIL.png";
import img_22 from "@/marquee/Canfin.png";
import img_23 from "@/marquee/Capacite.png";
import img_24 from "@/marquee/ceat.png";
import img_25 from "@/marquee/Centrum.png";
import img_26 from "@/marquee/cipla.png";
import img_27 from "@/marquee/Coal India.png";
import img_28 from "@/marquee/Cochin Shipyard.png";
import img_29 from "@/marquee/Dixon.png";
import img_30 from "@/marquee/Dr. Lal.png";
import img_31 from "@/marquee/EIL.png";
import img_32 from "@/marquee/Emaar.png";
import img_33 from "@/marquee/Ethos.png";
import img_34 from "@/marquee/Everest.png";
import img_35 from "@/marquee/Exicom.png";
import img_36 from "@/marquee/Exide.png";
import img_37 from "@/marquee/Exim.png";
import img_38 from "@/marquee/firstsource.png";
import img_39 from "@/marquee/GE vernova.png";
import img_40 from "@/marquee/GMR.png";
import img_41 from "@/marquee/GPT.png";
import img_42 from "@/marquee/Greenply.png";
import img_43 from "@/marquee/GSK.png";
import img_44 from "@/marquee/Gulf.png";
import img_45 from "@/marquee/HCG.png";
import img_46 from "@/marquee/HIL.png";
import img_47 from "@/marquee/Himadri.png";
import img_48 from "@/marquee/imgi_33_7_BW.png";
import img_49 from "@/marquee/Indiamart.png";
import img_50 from "@/marquee/IndianOil.png";
import img_51 from "@/marquee/Indigo paints.png";
import img_52 from "@/marquee/Inxo GFL.png";
import img_53 from "@/marquee/IRCTC.png";
import img_54 from "@/marquee/Jubilant.png";
import img_55 from "@/marquee/Kirloskar Grp.png";
import img_56 from "@/marquee/Kotak.png";
import img_57 from "@/marquee/Linde.png";
import img_58 from "@/marquee/Lodha.png";
import img_59 from "@/marquee/LT foods.png";
import img_60 from "@/marquee/Mankind.png";
import img_61 from "@/marquee/Marico.png";
import img_62 from "@/marquee/Marksans.png";
import img_63 from "@/marquee/Max healthcare.png";
import img_64 from "@/marquee/Moil.png";
import img_65 from "@/marquee/narayanahosp.png";
import img_66 from "@/marquee/Natco.png";
import img_67 from "@/marquee/Nueland.png";
import img_68 from "@/marquee/pharmeasy.png";
import img_69 from "@/marquee/Pitti.png";
import img_70 from "@/marquee/PTC.png";
import img_71 from "@/marquee/RPG life science.png";
import img_72 from "@/marquee/sbi_payments.png";
import img_73 from "@/marquee/Sembcorp.png";
import img_74 from "@/marquee/Sigachi.png";
import img_75 from "@/marquee/SMS.png";
import img_76 from "@/marquee/Solar.png";
import img_77 from "@/marquee/tastybite.png";
import img_78 from "@/marquee/Tata Commu.png";
import img_79 from "@/marquee/Tata Consumer.png";
import img_80 from "@/marquee/Zensar.png";

export const marqueeImages = [
  img_0,
  img_1,
  img_2,
  img_3,
  img_4,
  img_5,
  img_6,
  img_7,
  img_8,
  img_9,
  img_10,
  img_11,
  img_12,
  img_13,
  img_14,
  img_15,
  img_16,
  img_17,
  img_18,
  img_19,
  img_20,
  img_21,
  img_22,
  img_23,
  img_24,
  img_25,
  img_26,
  img_27,
  img_28,
  img_29,
  img_30,
  img_31,
  img_32,
  img_33,
  img_34,
  img_35,
  img_36,
  img_37,
  img_38,
  img_39,
  img_40,
  img_41,
  img_42,
  img_43,
  img_44,
  img_45,
  img_46,
  img_47,
  img_48,
  img_49,
  img_50,
  img_51,
  img_52,
  img_53,
  img_54,
  img_55,
  img_56,
  img_57,
  img_58,
  img_59,
  img_60,
  img_61,
  img_62,
  img_63,
  img_64,
  img_65,
  img_66,
  img_67,
  img_68,
  img_69,
  img_70,
  img_71,
  img_72,
  img_73,
  img_74,
  img_75,
  img_76,
  img_77,
  img_78,
  img_79,
  img_80,
];
